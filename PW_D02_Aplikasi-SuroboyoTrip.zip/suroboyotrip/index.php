<?php
require_once 'functions.php';
$destinations = getAllDestinations();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuroboyoTrip</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="icon" type="image/png" href="assets/images/logo.png">
</head>
<body>
    <!-- Header dan Navigasi -->
    <header>
        <div class="container">
            <img src="assets/images/logo.png" alt="Logo Perusahaan" class="logo">
            <h1 class="logo">SuroboyoTrip</h1>
            <nav>
                <ul class="nav-links" id="nav-links">
                    <li><a href="#beranda">Beranda</a></li>
                    <li><a href="#destinasi">Destinasi</a></li>
                    <li><a href="#visimisi">Visi & Misi</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Beranda Section -->
    <section id="beranda" class="beranda">
        <div class="container">
            <h2>Selamat Datang di Wisata Surabaya</h2>
            <p>Temukan keindahan dan keunikan destinasi wisata di Surabaya.</p>
            <a href="#destinasi" class="btn">Jelajahi Destinasi</a>
        </div>
    </section>

    <!-- Destinasi Section -->
    <section id="destinasi" class="destinasi">
        <div class="container">
            <h2>Destinasi Populer</h2>
            <div class="destinasi-grid">
                <?php foreach ($destinations as $dest): ?>
                <div class="destinasi-item">
                    <img src="<?php echo htmlspecialchars($dest['gambar']); ?>" alt="<?php echo htmlspecialchars($dest['nama']); ?>">
                    <h3><?php echo htmlspecialchars($dest['nama']); ?></h3>
                    <p><?php echo htmlspecialchars($dest['deskripsi']); ?></p>
                    <p class="rating">Rating: <?php 
                        $rating = $dest['rating'];
                        $fullStars = floor($rating);
                        $hasHalfStar = ($rating - $fullStars) >= 0.5;
                        
                        for ($i = 1; $i <= 5; $i++) {
                            if ($i <= $fullStars) {
                                echo "⭐";
                            } elseif ($i == $fullStars + 1 && $hasHalfStar) {
                                echo "⭐";
                            } else {
                                echo "☆";
                            }
                        }
                        echo " ($rating)";
                    ?></p>
                    <a href="<?php echo htmlspecialchars($dest['maps_link']); ?>" target="_blank" class="btn location-link">Lihat di Google Maps</a>
                    <a href="https://tiketwisata.surabaya.go.id/" target="_blank" class="btn">Beli Tiket</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>


    <!-- Tentang Kami Section -->
    <section id="visimisi" class="visimisi">
        <div class="container">
            <h2>Visi & Misi</h2>
            <h3>VISI : </h3>
            <p>Menjadi platform digital yang berguna untuk memudahkan mahasiswa rantau di Surabaya dalam beradaptasi, menikmati, menjelajah keindahan Kota Surabaya, serta menciptakan pengalaman kuliah yang lebih nyaman dan berkesan.</p>
            <h3>MISI : </h3>
            <ul>
                <li>Menyediakan informasi lengkap dan akurat tentang tempat wisata di Surabaya yang relevan bagi mahasiswa.</li>
                <li>Mempermudah proses pemesanan tiket dan akses ke destinasi wisata di Kota Surabaya dilengkapi dengan panduan yang mudah untuk diikuti.</li>
                <li>Membantu mahasiswa rantau dalam beradaptasi dengan budaya dan lingkungan lokal melalui konten informatif yang menarik dan bermanfaat.</li>
                <li>Mendorong eksplorasi Surabaya dengan cara yang aman, nyaman, dan ramah lingkungan, serta mempromosikan wisata lokal kepada generasi muda agar lebih dalam mengenal Kota Surabaya.</li>
            </ul>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 SuroboyoTrip. Semua Hak Cipta Dilindungi.</p>
    </footer>

    <script src="assets/js/script.js"></script>
</body>
</html>
