<?php
require_once 'config.php';

function getAllDestinations() {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM destinasi ORDER BY id ASC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}

function getDestinationById($id) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM destinasi WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
        return null;
    }
}

function searchDestinations($keyword) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM destinasi WHERE nama LIKE :keyword OR deskripsi LIKE :keyword");
        $keyword = "%$keyword%";
        $stmt->bindParam(':keyword', $keyword);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}
?>